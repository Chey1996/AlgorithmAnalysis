#include <fstream>
#include <string>
#include <iostream>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

//Function Prototype
double bruteForceMedian(int array[], double n);
double clock_start;
double clock_end;

//File variables
ofstream run_timers;

int main() {
//set random seed
srand (time(NULL));


        //unique array
    int A[5000];
    std::ofstream run_timers("output_unique.txt");
    double time;
    for(int i = 20; i < 5000; i = i + 20){ //fill array with 5000 in 20's
        for(int tests = 0; tests < 10; tests++){
            for(int j = 0; j < i; j++) {
                A[j] = j + 1;
            }
            clock_start = clock();
            bruteForceMedian(A, i);
            clock_end = clock();
            double run_time = (clock_end - clock_start)/CLOCKS_PER_SEC;
            time = time + run_time;
        }
        run_timers << time/10 << "\n";
        time = 0;
    }

            //mixed array large
    //int A[5000];
    //std::ofstream run_timers("output_mixed.txt");
    //double time;
    //for(int i = 20; i < 5000; i = i + 20){ //fill array with 5000 in 20's
    //    for(int tests = 0; tests < 10; tests++){
    //        for(int j = 0; j < i; j++) {
    //            A[j] = rand() % 5000;
    //        }
    //        clock_start = clock();
    //        bruteForceMedian(A, i);
    //        clock_end = clock();
    //        double run_time = (clock_end - clock_start)/CLOCKS_PER_SEC;
    //        time = time + run_time;
    //    }
    //    run_timers << time/10 << "\n";
    //    time = 0;
    //}


                //mixed array small
    //int A[5000];
    //std::ofstream run_timers("output_mixed_small.txt");
    //double time;
    //for(int i = 20; i < 5000; i = i + 20){ //fill array with 5000 in 20's
    //    for(int tests = 0; tests < 10; tests++){
    //        for(int j = 0; j < i; j++) {
    //            A[j] = rand() % 50;
    //        }
    //        clock_start = clock();
    //        bruteForceMedian(A, i);
    //        clock_end = clock();
    //        double run_time = (clock_end - clock_start)/CLOCKS_PER_SEC;
    //        time = time + run_time;
    //    }
    //    run_timers << time/10 << "\n";
    //    time = 0;
    //}

run_timers.close();
}

double bruteForceMedian(int array[], double n){
    double k = ceil(n/2);
    for(int i = 0; i <= n-1; i++){
        double numsmaller = 0, numequal = 0;
        for(int j = 0; j <= n-1; j++){
            if(array[j] < array[i]){
                numsmaller++;
            }
            else if(array[j] == array[i]) {
                numequal++;
            }
        }
        if((numsmaller < k) && (k<= (numsmaller + numequal))){
            return array[i];
        }
    }
}
