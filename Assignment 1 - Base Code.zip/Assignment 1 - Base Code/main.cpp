#include <iostream>
#include <fstream>
#include <string>
#include <iostream>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

//Function Prototype
double bruteForceMedian(int array[], double n);
double size = 0;

using namespace std;

int main()
{
int A[] = {1, 2, 4, 5, 6, 7};
size = (sizeof(A)/sizeof(*A));
int mean = bruteForceMedian(A, size);
cout << mean;
}

double bruteForceMedian(int array[], double n){
    double k = ceil(n/2);
    for(int i = 0; i <= n-1; i++){
        double numsmaller = 0, numequal = 0;
        for(int j = 0; j <= n-1; j++){
            if(array[j] < array[i]){
                numsmaller++;
            }
            else if(array[j] == array[i]) {
                numequal++;
            }
        }
        if((numsmaller < k) && (k<= (numsmaller + numequal))){
            return array[i];
        }
    }
}
