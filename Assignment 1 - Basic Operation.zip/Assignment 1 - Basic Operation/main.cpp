#include <fstream>
#include <string>
#include <iostream>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

//Function Prototype
int bruteForceMedian(int array[], int n);

//File variables
ofstream op;

int main() {

    //set random seed
    srand (time(NULL));

    //unique array
    //int A[5000];
    //std::ofstream op("output_unique.txt");
    //int op_count;
    //for(int i = 20; i < 5000; i = i + 20){ //fill array with 5000 in 20's
    //    for(int tests = 0; tests < 10; tests++){
    //        for(int j = 0; j < i; j++) {
    //            A[j] = j + 1;
    //        }
    //        op_count += bruteForceMedian(A, i);
    //    }
    //    cout << op_count;
    //    op << op_count/10 << "\n";
    //    op_count = 0;
    //}

    //mixed array large random
    //int A[5000];
    //std::ofstream op("output_mixed.txt");
    //int op_count;
    //for(int i = 20; i < 5000; i = i + 20){ //fill array with 5000 in 20's
    //    for(int tests = 0; tests < 10; tests++){
    //        for(int j = 0; j < i; j++) {
    //            A[j] = rand() % 5000;
    //        }
    //        op_count += bruteForceMedian(A, i);
    //    }
    //    cout << op_count;
    //    op << op_count/10 << "\n";
    //    op_count = 0;
    //}

    //mixed array small random
    int A[5000];
    std::ofstream op("output_mixed_small.txt");
    int op_count;
    for(int i = 20; i < 5000; i = i + 20){ //fill array with 5000 in 20's
        for(int tests = 0; tests < 10; tests++){
            for(int j = 0; j < i; j++) {
                A[j] = rand() % 50;
            }
            op_count += bruteForceMedian(A, i);
        }
        cout << op_count;
        op << op_count/10 << "\n";
        op_count = 0;
    }

    op.close();
}

int bruteForceMedian(int array[], int n){
    double k = ceil(n/2);
    int basic_op = 0;
    for(int i = 0; i <= n-1; i++){
        double numsmaller = 0, numequal = 0;
        for(int j = 0; j <= n-1; j++){
            basic_op = basic_op + 2;
            if(array[j] < array[i]){
                numsmaller++;
                basic_op = basic_op - 1;
            }
            else if(array[j] == array[i]) {
                numequal++;
            }
        }
        if((numsmaller < k) && (k<= (numsmaller + numequal))){
            return basic_op;
        }
    }
}
